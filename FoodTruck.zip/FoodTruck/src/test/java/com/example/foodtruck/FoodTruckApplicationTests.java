package com.example.foodtruck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodTruckApplicationTests {

	@Test
	void contextLoads() {
	}

}
